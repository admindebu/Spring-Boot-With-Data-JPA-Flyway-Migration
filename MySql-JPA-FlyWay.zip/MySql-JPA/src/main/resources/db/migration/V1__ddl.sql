use mysqlpoc;
   create table IF NOT EXISTS customer (
       id varchar(255) not null,
        code varchar(255),
        contact_number varchar(255),
        contract_number varchar(255),
        email varchar(255),
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table IF NOT EXISTS customer_level (
       level_id varchar(255) not null,
        child varchar(255),
        customer_id varchar(255),
        customer_level_type_id varchar(255),
        name varchar(255),
        show_name varchar(255),
        primary key (level_id)
    ) engine=InnoDB;
   
    create table IF NOT EXISTS customer_template (
       tmep_id varchar(255) not null,
        customer_id varchar(255),
        level varchar(255),
        parent_customer_level varchar(255),
        primary key (tmep_id)
    ) engine=InnoDB;
   
    create table IF NOT EXISTS history (
       id varchar(255) not null,
        action varchar(255),
        customer_id varchar(255),
        details varchar(255),
        updated_at datetime,
        updated_by varchar(255),
        primary key (id)
    ) engine=InnoDB;

    alter table customer_level 
       add constraint FKociom3uv2rm5s4oy7omwdmpel 
       foreign key (customer_level_type_id) 
       references customer_template (tmep_id);

    alter table customer_template 
       add constraint FK2s4vm59jkkig1lt0rtm7ujnqn 
       foreign key (customer_id) 
       references customer (id);
 
    alter table history 
       add constraint FKjbek4jc1j9ngptsyoud1pbu2f 
       foreign key (customer_id) 
       references customer (id);
       
 insert into customer (id,code,contact_number,contract_number,email,name)values("Id1","code1","588675674","77777777","demo@gmail.com","customer1");
