package com.org.techtalk.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity
public class CustomerTemplate {
	
	@Id
	private String tmepId; // DB UUID
	private String level;
	private String parentCustomerLevel;
	private String customerId; // DB UUID
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "customerLevelTypeId")
	private List<CustomerLevel> customerLevel;


}
