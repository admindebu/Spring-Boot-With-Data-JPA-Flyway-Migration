package com.org.techtalk.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity
public class CustomerLevel {
	
	@Id
	private String levelId; // DB UUID
	private String name;
	private String showName;
	private String child;
	private String customerLevelTypeId; // DB UUID
	private String customerId; // DB UUID

}
