package com.org.techtalk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.org.techtalk.entity.CustomerLevel;

@Repository
public interface CustomerLevelRespository extends JpaRepository<CustomerLevel, String>{
	


}
