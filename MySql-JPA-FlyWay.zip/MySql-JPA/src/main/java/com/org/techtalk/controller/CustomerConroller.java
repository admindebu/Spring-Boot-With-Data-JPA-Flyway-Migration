package com.org.techtalk.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.techtalk.entity.Customer;
import com.org.techtalk.service.CustomerService;

@RestController
@RequestMapping(produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class CustomerConroller {

	@Autowired
	private CustomerService customerService;

	@PostMapping(value = "/api/v1/customer", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Customer> saveClient(@RequestBody Customer customer) {

		return new ResponseEntity<>(customerService.save(customer), HttpStatus.OK);

	}

	@GetMapping(value = "/api/v1/customer/{customerId}")
	public ResponseEntity<Optional<Customer>> findOneClientLevelTemplate(@PathVariable String customerId) {

		return new ResponseEntity<>(customerService.findAllLevelTemplateById(customerId), HttpStatus.OK);

	}

	@GetMapping(value = "/api/v1/customer-level/{customerId}")
	public ResponseEntity<Optional<Customer>> findOneClientLevel(@PathVariable String customerId) {

		return new ResponseEntity<>(customerService.findAllLevelTemplateById(customerId), HttpStatus.OK);

	}

}
