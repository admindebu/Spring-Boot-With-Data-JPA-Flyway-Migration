package com.org.techtalk.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.org.techtalk.entity.Customer;
import com.org.techtalk.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Transactional
	public Customer save(Customer customer) {
		return customerRepository.save(customer);
	}

	@Transactional
	public Optional<Customer> findById(String id) {
		return customerRepository.findById(id);
	}

	
	@Transactional
	public Optional<Customer> findAllLevelTemplateById(String customerId) {
		return customerRepository.findAllLevelById(customerId);
	}
	
	
	@Transactional
	public Optional<Customer> findAllLevelById(String customerId) {
		return customerRepository.findAllLevelById(customerId);
	}
	
	

}
